#!/system/bin/sh

if [ -f /data/adb/zapret/autostart ]; then
    zapret start
fi