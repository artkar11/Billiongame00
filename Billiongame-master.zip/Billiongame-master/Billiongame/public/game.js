// В самом начале файла ЗАМЕНИ на это:
const Game = {
    // ... все твои переменные без изменений ...
    
    // API конфиг для Cloudflare Pages
    API_CONFIG: {
        // Cloudflare Pages автоматически проксирует /api
        BASE_URL: '', // ОСТАВЬ ПУСТЫМ!
        TOKEN: 'a11ced6f7e3121b48a09114f1c20674bd317f'
    },
    
    // ИЗМЕНЕННЫЙ apiRequest метод:
    async apiRequest(endpoint, method = 'POST', data = null) {
        // Для Cloudflare Pages используем относительные пути
        const url = endpoint; // /api/login, /api/register и т.д.
        
        try {
            const options = {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.API_CONFIG.TOKEN}`
                }
            };
            
            if (data) {
                options.body = JSON.stringify(data);
            }
            
            const response = await fetch(url, options);
            
            // Если ответ 404 (API не развернут) - используем localStorage
            if (response.status === 404) {
                console.log('API не найден, используем localStorage');
                throw new Error('API не настроен');
            }
            
            return await response.json();
        } catch (error) {
            console.log('⚠️ API недоступен:', error.message);
            // Возвращаем специальный код для fallback
            return { 
                success: false, 
                error: 'API_OFFLINE',
                message: 'Используется локальное сохранение'
            };
        }
    },
    
    // ИЗМЕНЕННЫЙ login метод:
    async login(username, password) {
        if (!username || !password) {
            this.showNotification('Заполните все поля!', 'error');
            return { success: false };
        }
        
        // Проверка админа
        const adminPassword = '041404300440043a0020043d043500200434043e043a0441044c0020043f04360020';
        if (username === 'ADMIN' && password === adminPassword) {
            this.currentUser = { username: 'ADMIN', isAdmin: true };
            this.loadGameSave();
            this.saveAllData();
            this.updateProfileDisplay();
            
            if (window.Admin) Admin.unlockAdmin();
            this.showNotification('👑 Добро пожаловать, ADMIN!', 'success');
            return { success: true, isAdmin: true };
        }
        
        // Пробуем API
        const apiResult = await this.apiRequest('/api/login', 'POST', {
            username,
            password
        });
        
        // Если API недоступен ИЛИ вернул API_OFFLINE - используем localStorage
        if (!apiResult.success && apiResult.error === 'API_OFFLINE') {
            console.log('Cloudflare API не настроен, используем localStorage');
            return this.localStorageLogin(username, password);
        }
        
        // Если API доступен и успешно ответил
        if (apiResult.success) {
            this.currentUser = {
                username: apiResult.user.username,
                isAdmin: apiResult.user.isAdmin || false
            };
            
            if (apiResult.gameData) {
                this.money = apiResult.gameData.money || 0;
                this.clickValue = apiResult.gameData.clickValue || 1;
                this.passiveIncome = apiResult.gameData.passiveIncome || 0;
                this.prestigeLevel = apiResult.gameData.prestigeLevel || 0;
                this.prestigeBonus = apiResult.gameData.prestigeBonus || 1.0;
                this.upgrades = apiResult.gameData.upgrades || {};
                this.achievements = apiResult.gameData.achievements || [];
                this.totalClicks = apiResult.gameData.totalClicks || 0;
            }
            
            localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
            this.saveGameLocal();
            
            this.updateProfileDisplay();
            this.showNotification(`✅ Вход выполнен, ${username}!`, 'success');
            
            if (this.currentUser.isAdmin && window.Admin) {
                Admin.unlockAdmin();
            }
            
            return { success: true, isAdmin: this.currentUser.isAdmin };
        }
        
        // Если API доступен но вернул ошибку (неверный логин/пароль)
        this.showNotification(apiResult.error || 'Ошибка входа', 'error');
        return { success: false };
    }
};