// Объект мини-игр
const MiniGames = {
    init() {
        this.createGameButtons();
    },
    
    // Создание кнопок мини-игр
    createGameButtons() {
        const games = [
            {
                name: '🎰 Однорукий бандит',
                description: 'Ставка: $100',
                color: '#FF416C',
                action: () => this.slotMachine()
            },
            {
                name: '💣 Сапёр',
                description: 'Ставка: $200',
                color: '#32CD32',
                action: () => this.minesweeper()
            },
            {
                name: '🎯 Угадай шарик',
                description: 'Ставка: $150',
                color: '#FFD700',
                action: () => this.cupsGame()
            },
            {
                name: '🃏 Блэкджек',
                description: 'Ставка: $500',
                color: '#1E90FF',
                action: () => this.blackjack()
            },
            {
                name: '🎡 Рулетка',
                description: 'Ставка: $300',
                color: '#8A2BE2',
                action: () => this.roulette()
            },
            {
                name: '🎯 Тире-мишень',
                description: 'Ставка: $250',
                color: '#FF4500',
                action: () => this.targetGame()
            }
        ];
        
        const container = document.getElementById('minigamesGrid');
        container.innerHTML = '';
        
        games.forEach(game => {
            const button = document.createElement('button');
            button.className = 'minigame-btn';
            button.style.background = `linear-gradient(135deg, ${game.color}, ${this.darkenColor(game.color, 0.2)})`;
            button.innerHTML = `
                <div style="font-size: 1.3em; margin-bottom: 5px;">${game.name}</div>
                <div style="font-size: 0.9em; opacity: 0.9;">${game.description}</div>
            `;
            button.onclick = game.action;
            container.appendChild(button);
        });
    },
    
    // Затемнение цвета
    darkenColor(color, amount) {
        const num = parseInt(color.replace('#', ''), 16);
        const amt = Math.round(2.55 * amount * 100);
        const R = (num >> 16) - amt;
        const G = (num >> 8 & 0x00FF) - amt;
        const B = (num & 0x0000FF) - amt;
        return '#' + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
                     (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
                     (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
    },
    
    // === СЛОТ-МАШИНА ===
    slotMachine() {
        this.startGame('slot', 100, (bet) => {
            const symbols = ['🍒', '🍋', '🍊', '⭐', '🔔', '7️⃣', '💎', '👑'];
            const reels = [
                symbols[Math.floor(Math.random() * symbols.length)],
                symbols[Math.floor(Math.random() * symbols.length)],
                symbols[Math.floor(Math.random() * symbols.length)]
            ];
            
            let result = `🎰 | ${reels[0]} | ${reels[1]} | ${reels[2]} | 🎰\n\n`;
            
            if (reels[0] === reels[1] && reels[1] === reels[2]) {
                const win = bet * 20;
                Game.money += win;
                result += `🎉 ДЖЕКПОТ! 3 одинаковых!\n+$${this.formatNumber(win)}`;
            } else if (reels[0] === reels[1] || reels[1] === reels[2]) {
                const win = bet * 3;
                Game.money += win;
                result += `👍 2 одинаковых!\n+$${this.formatNumber(win)}`;
            } else if (reels[0] === '7️⃣' || reels[1] === '7️⃣' || reels[2] === '7️⃣') {
                const win = bet * 2;
                Game.money += win;
                result += `✨ Счастливая 7!\n+$${this.formatNumber(win)}`;
            } else {
                result += "💔 Ничего... Попробуй еще!";
            }
            
            return result;
        });
    },
    
    // === САПЁР ===
    minesweeper() {
        this.startGame('mines', 200, (bet) => {
            // Простая версия: 3x3, 1 мина
            const minePos = Math.floor(Math.random() * 9);
            let revealed = Array(9).fill(false);
            let attempts = 3;
            let result = "💣 САПЁР - 1 мина, 3 попытки\n\n";
            
            const showBoard = () => {
                let board = "";
                for (let i = 0; i < 9; i++) {
                    if (i % 3 === 0) board += "\n";
                    if (revealed[i]) {
                        board += i === minePos ? "💥" : "✅";
                    } else {
                        board += "⬜";
                    }
                }
                return board;
            };
            
            for (let attempt = 1; attempt <= 3; attempt++) {
                result += `\nПопытка ${attempt}/3:\n${showBoard()}\n`;
                
                const choice = parseInt(prompt(`Выбери клетку 1-9:\n${result}`)) - 1;
                
                if (choice < 0 || choice > 8 || isNaN(choice)) {
                    result += "\n❌ Неверный ввод!";
                    break;
                }
                
                revealed[choice] = true;
                
                if (choice === minePos) {
                    result += "\n💥 БАБАХ! Наступил на мину!";
                    return result;
                }
            }
            
            // Если выжил
            const safeCells = revealed.filter((v, i) => v && i !== minePos).length;
            const win = bet * (safeCells + 1);
            Game.money += win;
            result += `\n🎉 ПОБЕДА! Найдено ${safeCells} безопасных клеток!\n+$${this.formatNumber(win)}`;
            
            return result;
        });
    },
    
    // === ШАРИК ПОД ЧАШКОЙ ===
    cupsGame() {
        this.startGame('cups', 150, (bet) => {
            const ballPos = Math.floor(Math.random() * 3);
            let result = "🎯 УГАДАЙ ПОД КАКОЙ ЧАШКОЙ ШАРИК\n\n";
            result += "1️⃣   2️⃣   3️⃣\n";
            result += "🎯   🎯   🎯\n\n";
            
            const guess = parseInt(prompt(result + "Выбери чашку (1-3):")) - 1;
            
            result += "\nРезультат:\n";
            for (let i = 0; i < 3; i++) {
                result += i === ballPos ? "⚽ " : "🎯 ";
            }
            result += "\n\n";
            
            if (guess === ballPos) {
                const win = bet * 4;
                Game.money += win;
                result += `🎉 УГАДАЛ! Шарик под чашкой ${ballPos + 1}\n+$${this.formatNumber(win)}`;
            } else {
                result += `💔 Не угадал... Шарик был под чашкой ${ballPos + 1}`;
            }
            
            return result;
        });
    },
    
    // === БЛЭКДЖЕК ===
    blackjack() {
        this.startGame('blackjack', 500, (bet) => {
            const cards = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
            const values = {
                '2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, '10':10,
                'J':10, 'Q':10, 'K':10, 'A':11
            };
            
            let playerCards = [];
            let dealerCards = [];
            let gameLog = "🃏 БЛЭКДЖЕК (21 очко)\n\n";
            
            // Раздача
            playerCards.push(this.drawCard(cards));
            dealerCards.push(this.drawCard(cards));
            playerCards.push(this.drawCard(cards));
            dealerCards.push(this.drawCard(cards));
            
            const calculateScore = (hand) => {
                let score = hand.reduce((sum, card) => sum + values[card], 0);
                let aces = hand.filter(card => card === 'A').length;
                while (score > 21 && aces > 0) {
                    score -= 10;
                    aces--;
                }
                return score;
            };
            
            // Игрок
            let playerTurn = true;
            while (playerTurn) {
                const playerScore = calculateScore(playerCards);
                gameLog += `Твои карты: ${playerCards.join(', ')} (${playerScore})\n`;
                gameLog += `Карта дилера: ${dealerCards[0]}, ?\n`;
                
                if (playerScore >= 21) {
                    playerTurn = false;
                    break;
                }
                
                const choice = prompt(gameLog + "\n1. Взять карту\n2. Остановиться");
                
                if (choice === '1') {
                    playerCards.push(this.drawCard(cards));
                    if (calculateScore(playerCards) > 21) {
                        gameLog += "\n💥 ПЕРЕБОР!";
                        playerTurn = false;
                    }
                } else {
                    playerTurn = false;
                }
            }
            
            // Дилер
            const playerScore = calculateScore(playerCards);
            let dealerScore = calculateScore(dealerCards);
            
            if (playerScore <= 21) {
                while (dealerScore < 17) {
                    dealerCards.push(this.drawCard(cards));
                    dealerScore = calculateScore(dealerCards);
                }
            }
            
            gameLog += `\n=== РЕЗУЛЬТАТ ===\n`;
            gameLog += `Твои карты: ${playerCards.join(', ')} (${playerScore})\n`;
            gameLog += `Карты дилера: ${dealerCards.join(', ')} (${dealerScore})\n\n`;
            
            if (playerScore > 21) {
                gameLog += "💔 ПЕРЕБОР! Ты проиграл.";
            } else if (dealerScore > 21) {
                const win = bet * 2;
                Game.money += win;
                gameLog += `🎉 ДИЛЕР ПЕРЕБОР! ПОБЕДА!\n+$${this.formatNumber(win)}`;
            } else if (playerScore > dealerScore) {
                const win = bet * 2;
                Game.money += win;
                gameLog += `🎉 ТЫ ВЫИГРАЛ! ${playerScore} > ${dealerScore}\n+$${this.formatNumber(win)}`;
            } else if (playerScore === dealerScore) {
                Game.money += bet; // Возврат
                gameLog += "🤝 НИЧЬЯ! Ставка возвращена.";
            } else {
                gameLog += `💔 ПРОИГРЫШ! ${playerScore} < ${dealerScore}`;
            }
            
            return gameLog;
        });
    },
    
    // === РУЛЕТКА ===
    roulette() {
        this.startGame('roulette', 300, (bet) => {
            const number = Math.floor(Math.random() * 37); // 0-36
            const isRed = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(number);
            
            let result = `🎡 РУЛЕТКА - Выпало: ${number} ${isRed ? '🔴' : number === 0 ? '🟢' : '⚫'}\n\n`;
            
            const choice = prompt(result + "Ставка на:\n1. Красное (x2)\n2. Черное (x2)\n3. Четное (x2)\n4. Нечетное (x2)\n5. Конкретное число (x36)\n\nВведите номер:");
            
            let win = 0;
            switch(choice) {
                case '1': win = isRed ? bet * 2 : 0; break;
                case '2': win = !isRed && number !== 0 ? bet * 2 : 0; break;
                case '3': win = number % 2 === 0 && number !== 0 ? bet * 2 : 0; break;
                case '4': win = number % 2 === 1 ? bet * 2 : 0; break;
                case '5': 
                    const num = parseInt(prompt("Введи число (0-36):"));
                    win = num === number ? bet * 36 : 0;
                    break;
                default: win = 0;
            }
            
            if (win > 0) {
                Game.money += win;
                result += `🎉 ВЫИГРЫШ! +$${this.formatNumber(win)}`;
            } else {
                result += "💔 Проигрыш";
            }
            
            return result;
        });
    },
    
    // === ТИРЕ-МИШЕНЬ ===
    targetGame() {
        this.startGame('target', 250, (bet) => {
            const target = Math.floor(Math.random() * 100) + 1;
            let result = `🎯 ТИРЕ-МИШЕНЬ\nУгадай число от 1 до 100\n\n`;
            
            for (let attempt = 1; attempt <= 5; attempt++) {
                const guess = parseInt(prompt(result + `Попытка ${attempt}/5:`));
                
                if (isNaN(guess) || guess < 1 || guess > 100) {
                    result += "❌ Неверный ввод!\n";
                    break;
                }
                
                const difference = Math.abs(target - guess);
                
                if (difference === 0) {
                    const win = bet * 10;
                    Game.money += win;
                    result += `🎯 БИНГО! Точное попадание!\n+$${this.formatNumber(win)}`;
                    return result;
                } else if (difference <= 5) {
                    const win = bet * 5;
                    Game.money += win;
                    result += `🎯 Очень близко! Разница: ${difference}\n+$${this.formatNumber(win)}`;
                    return result;
                } else if (difference <= 15) {
                    result += `🎯 Близко! Разница: ${difference}\n`;
                } else if (guess < target) {
                    result += `🔺 Больше!\n`;
                } else {
                    result += `🔻 Меньше!\n`;
                }
            }
            
            result += `\n💔 Не угадал... Число было: ${target}`;
            return result;
        });
    },
    
    // Вспомогательные методы
    drawCard(deck) {
        return deck[Math.floor(Math.random() * deck.length)];
    },
    
    startGame(gameName, minBet, gameLogic) {
        if (Game.money < minBet) {
            alert(`Минимальная ставка: $${minBet}\nУ вас: $${Game.formatNumber(Game.money)}`);
            return;
        }
        
        const bet = parseInt(prompt(`Ставка (мин. $${minBet}):`, minBet));
        
        if (!bet || bet < minBet) {
            alert(`Минимум $${minBet}!`);
            return;
        }
        
        if (bet > Game.money) {
            alert("Недостаточно денег!");
            return;
        }
        
        Game.money -= bet;
        Game.updateDisplay();
        
        const result = gameLogic(bet);
        alert(result);
        Game.updateDisplay();
        Game.saveGame();
    },
    
    formatNumber(num) {
        return Game.formatNumber(num);
    }
};

// Инициализация при загрузке
window.addEventListener('load', () => {
    MiniGames.init();
});