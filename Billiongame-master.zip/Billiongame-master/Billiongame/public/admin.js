// admin.js - полный файл
const Admin = {
    isAdmin: false,
    secretCode: 'ADMIN12345',
    
    init() {
        this.checkAdmin();
        this.setupHotkeys();
        console.log('👮 Админка инициализирована');
    },
    
    checkAdmin() {
        // Проверяем есть ли текущий пользователь и он ли админ
        if (Game && Game.currentUser && Game.currentUser.isAdmin) {
            this.unlockAdmin();
            return;
        }
        
        // Проверяем секретный код в localStorage
        const savedAdmin = localStorage.getItem('isAdmin');
        if (savedAdmin === 'true') {
            this.unlockAdmin();
        }
        
        // Проверяем URL параметр
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('admin') === this.secretCode) {
            this.unlockAdmin();
        }
    },
    
    setupHotkeys() {
        let keySequence = '';
        document.addEventListener('keydown', (e) => {
            keySequence += e.key.toUpperCase();
            if (keySequence.length > 20) keySequence = keySequence.slice(-20);
            
            // Секретный код
            if (keySequence.includes(this.secretCode)) {
                this.unlockAdmin();
                keySequence = '';
            }
            
            // Быстрые команды
            if (e.ctrlKey && e.shiftKey) {
                switch(e.key.toUpperCase()) {
                    case 'A': this.unlockAdmin(); break;
                    case 'M': this.addMoney(1000000); break;
                    case 'R': this.resetGame(); break;
                }
            }
        });
        
        // Двойной клик по заголовку
        const title = document.querySelector('h1');
        if (title) {
            title.addEventListener('dblclick', () => {
                this.unlockAdmin();
            });
        }
    },
    
    unlockAdmin() {
        this.isAdmin = true;
        localStorage.setItem('isAdmin', 'true');
        
        // Показываем вкладку админа
        const adminTab = document.getElementById('adminTab');
        if (adminTab) {
            adminTab.style.display = 'block';
            adminTab.classList.add('admin-tab');
        }
        
        // Показываем уведомление
        this.showNotification('🔓 Админ-панель разблокирована!', 'success');
        
        // Добавляем панель управления если её нет
        this.createAdminPanel();
        
        console.log('⚡ Админ-режим активирован');
    },
    
    createAdminPanel() {
        if (document.getElementById('adminPanel')) return;
        
        const panel = document.createElement('div');
        panel.id = 'adminPanel';
        panel.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: rgba(0,0,0,0.95);
            border: 2px solid gold;
            border-radius: 10px;
            padding: 15px;
            z-index: 9999;
            color: white;
            min-width: 300px;
            box-shadow: 0 0 20px rgba(255,215,0,0.5);
            font-family: monospace;
        `;
        
        panel.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h4 style="margin: 0; color: gold;"><i class="fas fa-crown"></i> АДМИН-ПАНЕЛЬ</h4>
                <button onclick="Admin.hidePanel()" style="background: red; color: white; border: none; border-radius: 5px; padding: 5px 10px; cursor: pointer;">
                    ✕
                </button>
            </div>
            
            <div style="margin-bottom: 15px;">
                <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                    <input type="number" id="adminMoneyInput" placeholder="Сумма" 
                           style="flex: 1; padding: 8px; border-radius: 5px; border: 1px solid #00BFFF; background: #222; color: white;">
                    <button onclick="Admin.addMoneyFromInput()" 
                            style="background: #00BFFF; color: white; border: none; border-radius: 5px; padding: 8px 15px; cursor: pointer;">
                        💰 Добавить
                    </button>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <button onclick="Admin.addMoney(1000)" class="admin-quick-btn">+$1K</button>
                    <button onclick="Admin.addMoney(10000)" class="admin-quick-btn">+$10K</button>
                    <button onclick="Admin.addMoney(100000)" class="admin-quick-btn">+$100K</button>
                    <button onclick="Admin.addMoney(1000000)" class="admin-quick-btn">+$1M</button>
                </div>
            </div>
            
            <div style="border-top: 1px solid #333; padding-top: 15px;">
                <button onclick="Admin.unlockAllUpgrades()" style="width: 100%; padding: 10px; background: #8A2BE2; color: white; border: none; border-radius: 5px; margin-bottom: 10px; cursor: pointer;">
                    🔓 Разблокировать все улучшения
                </button>
                <button onclick="Admin.maxPrestige()" style="width: 100%; padding: 10px; background: #FFD700; color: black; border: none; border-radius: 5px; margin-bottom: 10px; cursor: pointer;">
                    👑 Максимальный престиж
                </button>
                <button onclick="Admin.cheatAchievements()" style="width: 100%; padding: 10px; background: #32CD32; color: white; border: none; border-radius: 5px; margin-bottom: 10px; cursor: pointer;">
                    🏆 Получить все достижения
                </button>
                <button onclick="Admin.resetGame()" style="width: 100%; padding: 10px; background: red; color: white; border: none; border-radius: 5px; cursor: pointer;">
                    🗑️ Полный сброс игры
                </button>
            </div>
            
            <div style="margin-top: 15px; font-size: 12px; color: #888; text-align: center;">
                👑 Админ-режим активирован
            </div>
        `;
        
        // Добавляем стили для кнопок
        const style = document.createElement('style');
        style.textContent = `
            .admin-quick-btn {
                padding: 8px;
                background: #333;
                color: white;
                border: 1px solid #555;
                border-radius: 5px;
                cursor: pointer;
                transition: all 0.2s;
            }
            
            .admin-quick-btn:hover {
                background: #444;
                border-color: #00BFFF;
            }
            
            .admin-tab {
                background: linear-gradient(135deg, gold, orange) !important;
                color: black !important;
                font-weight: bold !important;
            }
        `;
        document.head.appendChild(style);
        
        document.body.appendChild(panel);
    },
    
    hidePanel() {
        const panel = document.getElementById('adminPanel');
        if (panel) {
            panel.style.display = 'none';
        }
    },
    
    showPanel() {
        const panel = document.getElementById('adminPanel');
        if (panel) {
            panel.style.display = 'block';
        }
    },
    
    addMoneyFromInput() {
        const input = document.getElementById('adminMoneyInput');
        const amount = parseInt(input.value);
        
        if (amount && amount > 0) {
            this.addMoney(amount);
            input.value = '';
        } else {
            this.showNotification('Введите корректную сумму!', 'error');
        }
    },
    
    addMoney(amount) {
        if (!this.isAdmin) {
            this.showNotification('Нет прав администратора!', 'error');
            return;
        }
        
        if (Game) {
            Game.money += amount;
            Game.updateDisplay();
            Game.saveAllData();
            
            this.showNotification(`✅ Добавлено $${Game.formatNumber(amount)}`, 'success');
            console.log(`💰 Админ добавил $${amount}`);
        }
    },
    
    unlockAllUpgrades() {
        if (!this.isAdmin || !Game) return;
        
        Object.values(Game.upgrades).forEach(upgrade => {
            upgrade.count = 999;
            upgrade.cost = 1;
            
            if (upgrade.type === 'click') {
                Game.clickValue += upgrade.value * 999;
            } else if (upgrade.type === 'passive') {
                Game.passiveIncome += upgrade.value * 999;
            }
        });
        
        Game.updateDisplay();
        Game.saveAllData();
        this.showNotification('✅ Все улучшения разблокированы!', 'success');
    },
    
    maxPrestige() {
        if (!this.isAdmin || !Game) return;
        
        Game.prestigeLevel = 100;
        Game.prestigeBonus = 11.0;
        
        Game.updateDisplay();
        Game.saveAllData();
        this.showNotification('👑 Престиж 100 уровня! Бонус x11.0', 'success');
    },
    
    cheatAchievements() {
        if (!this.isAdmin || !Game) return;
        
        const achievements = [
            'first_thousand', 'millionaire', 'billionaire', 'click_master',
            'upgrade_king', 'prestige_master', 'minigame_champion', 'secret_found'
        ];
        
        Game.achievements = achievements;
        Game.money += 1000000;
        
        Game.updateDisplay();
        Game.saveAllData();
        this.showNotification('🏆 Все достижения получены! +$1,000,000', 'success');
    },
    
    resetGame() {
        if (!this.isAdmin) return;
        
        if (confirm('ТОЧНО сбросить всю игру?\nЭто удалит все сохранения!')) {
            localStorage.clear();
            location.reload();
        }
    },
    
    showNotification(message, type = 'info') {
        // Удаляем старое уведомление
        const oldNotify = document.getElementById('adminNotification');
        if (oldNotify) oldNotify.remove();
        
        // Создаем новое
        const notify = document.createElement('div');
        notify.id = 'adminNotification';
        notify.style.cssText = `
            position: fixed;
            top: 50px;
            right: 20px;
            background: ${type === 'success' ? '#32CD32' : type === 'error' ? '#FF416C' : '#1E90FF'};
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            z-index: 10000;
            animation: slideIn 0.3s ease;
            font-weight: bold;
        `;
        
        const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
        notify.textContent = `${icon} ${message}`;
        
        // Анимация
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
        
        document.body.appendChild(notify);
        
        // Автоудаление
        setTimeout(() => {
            notify.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notify.remove(), 300);
            
            const slideOutStyle = document.createElement('style');
            slideOutStyle.textContent = `
                @keyframes slideOut {
                    from { transform: translateX(0); opacity: 1; }
                    to { transform: translateX(100%); opacity: 0; }
                }
            `;
            document.head.appendChild(slideOutStyle);
        }, 3000);
    }
};

// Глобальные функции для кнопок в HTML
function addMoney() {
    const amount = parseInt(document.getElementById('adminMoney').value);
    if (amount && amount > 0) {
        Admin.addMoney(amount);
    }
}

function unlockAll() {
    Admin.unlockAllUpgrades();
}

function resetGame() {
    Admin.resetGame();
}

// Инициализация админки при загрузке
window.addEventListener('load', () => {
    Admin.init();
});