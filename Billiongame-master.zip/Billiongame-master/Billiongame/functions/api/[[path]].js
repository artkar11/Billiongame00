// functions/api/[[path]].js
export default {
    async fetch(request, env) {
        const url = new URL(request.url);
        const path = url.pathname;
        const method = request.method;
        
        // CORS headers
        const corsHeaders = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        };
        
        if (method === 'OPTIONS') {
            return new Response(null, { headers: corsHeaders });
        }
        
        // Проверка токена
        const authHeader = request.headers.get('Authorization');
        const validToken = 'a11ced6f7e3121b48a09114f1c20674bd317f';
        
        if (!authHeader || !authHeader.includes(validToken)) {
            return jsonResponse({ error: 'Unauthorized' }, 401, corsHeaders);
        }
        
        try {
            // Инициализация БД
            await initDatabase(env.DB);
            
            // Маршруты API
            switch(path) {
                case '/api/register':
                    return await handleRegister(request, env.DB);
                case '/api/login':
                    return await handleLogin(request, env.DB);
                case '/api/save':
                    return await handleSaveGame(request, env.DB);
                case '/api/load':
                    return await handleLoadGame(request, env.DB);
                case '/api/promo/activate':
                    return await handleActivatePromo(request, env.DB);
                case '/api/admin/users':
                    return await handleAdminUsers(request, env.DB);
                default:
                    return jsonResponse({ 
                        message: 'Billionaire Game API',
                        endpoints: [
                            '/api/register',
                            '/api/login', 
                            '/api/save',
                            '/api/load',
                            '/api/promo/activate'
                        ]
                    }, 200, corsHeaders);
            }
        } catch (error) {
            console.error('API Error:', error);
            return jsonResponse({ error: error.message }, 500, corsHeaders);
        }
    }
};

// ... остальной API код (регистрация, логин и т.д.) ...